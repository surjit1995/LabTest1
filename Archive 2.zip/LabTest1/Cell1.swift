//
//  Cell.swift
//  LabTest1
//
//  Created by MacStudent on 2020-01-14.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import Foundation
import UIKit

class Cell1 : UITableViewCell
{
    @IBOutlet weak var  label1: UILabel!
    @IBOutlet weak var  label2: UILabel!
    @IBOutlet weak var  label3: UILabel!
    @IBOutlet weak var  label4: UILabel!
}
